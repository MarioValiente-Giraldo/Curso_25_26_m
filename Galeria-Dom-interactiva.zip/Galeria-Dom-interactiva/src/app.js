import imageCard from './components/imageCard';
import { imagesData } from './db/imagenes';

function app() {
  //Seleccionamos el div con id=app que está en index.html

  const divApp = document.getElementById('app');
  //Siempre validar que divApp existe
  if(!divApp)throw new Error('Error: No se encontró el contenedor con id = app');


  //---- Limpiar el contenedor div con id=app ----
  divApp.innerHTML='';

  const header = document.createElement('div');
  header.className='text-center mb-10 py-6';
  const title = document.createElement('h1');
  title.className = 'text-4xl font-bold text-purple-600 mb-2';
  title.textContent='🖼️ Galería de imágenes 🖼️';
  const subtitle = `
  <p>
    <h3>
      Explora y Visualiza 
    </h3>
  </p>
  `;
  //Falta subtitulo
  header.append(title,subtitle);

  //------ construcción de las imágenes ------

  const grid = document.createElement('div');
  grid.className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mx-w-6xl mx-auto px-4';


  
  imagesData.forEach(image=>{
    const tarjeta = imageCard(image);
    //Voy a inyectar a cada tarjeta un atributo (dataset)
    tarjeta.dataset.imageId=image.id;
    grid.append(tarjeta);
  });

  divApp.append(header,grid);

}

export default app;

