//Tarjeta (card) de imagen

export const imageCard = (image) => {
  const { src,title } = image;
  //createElement <----- Crear en memoria un elemento de HTML
  const card = document.createElement('div');

  card.className=
    'bg-white rounded-xt shadow-lg overflow-hidden hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer';

  //Contenedor de la imagen
  const imageContainer = document.createElement('div');
  imageContainer.className=
  'relative aspect-square overflow-hidden bg-gray-200 ';
  const img = document.createElement('img');
  img.src=image.url;
  img.alt = image.title;
  img.className = 'w-full h-full object-cover';
  //Object-cover ----> Ocupa todo el espacio sin deformarse
  
  //Botón del corazón
  const heartButton = document.createElement('button');
  heartButton.className='absolute top-2 right-2 bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg hover:scale-100 transition-transform z-10 cursor-pointer';
  heartButton.textContent='🩶';
  heartButton.title='Añadir a favoritos';
  heartButton.addEventListener('click',function (event){
    //stopPropagation
    event.stopPropagation();
    //<--- Aquí lanzaremos la función que gestione el añadir o quitar favoritos
    if(heartButton.textContent==='🩶'){
      heartButton.textContent='♥️';
      localStorage.setItem();

    } else {
      heartButton.textContent='🩶';

    }
    
    
  });

  //-------- **** imageContainer.append ****--------
  imageContainer.append(img, heartButton);

  //Información de la imagen, autor, categoría
  const infoContainer = document.createElement('div');
  infoContainer.className='p-4';
  //Titulo
  const titleInfo = document.createElement('h3');
  titleInfo.textContent=image.title;
  titleInfo.className='font-bold text-lg text-gray-800 mb-1 truncate';

  //Autor
  const author = document.createElement('p');
  author.textContent=`Author: ${image.author}`;
  author.className='text-sm text-gray-600 truncate';

  const category = document.createElement('p');
  category.textContent=`Categoy: ${image.category}`;
  category.className='text-sm text-gray-700 truncate';



  //-------- **** infoContainer.append ****--------
  infoContainer.append(titleInfo, author, category);


  card.addEventListener('click',function(){
    alert(`Abriendo la imagen: ${image.title}`);
  });
  
  
  //-------- **** card.append ****--------
  card.append(imageContainer, infoContainer);

  return card;

};

export default imageCard;
